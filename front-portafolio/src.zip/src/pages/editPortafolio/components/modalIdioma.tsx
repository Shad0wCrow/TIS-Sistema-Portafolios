import { useState, type ChangeEvent } from "react";
import styles from "./modals.module.css";
import { addIdioma, getSugerenciasIdioma } from "../../../services/portafolioservice";
import AutocompleteInput from "../../../components/ui/AutocompleteInput/AutocompleteInput";

const IDIOMAS_COMUNES = [
  "Español", "Inglés", "Portugués", "Francés", "Alemán", "Italiano",
  "Chino", "Japonés", "Coreano", "Ruso", "Árabe", "Hindi", "Quechua",
];

interface ModalIdiomaProps {
  onClose: () => void;
  onSave: (data: Parameters<typeof addIdioma>[0]) => Promise<boolean | void>;
  duplicadoWarning?: string;
}

interface FormErrors {
  nombre?: string;
  nivel?: string;
}

export default function ModalIdioma({ onClose, onSave, duplicadoWarning }: ModalIdiomaProps) {
  const [form, setForm] = useState({
    nombre: "",
    nivel: "",
    visibilidad: "publico" as "publico" | "privado",
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [loading, setLoading] = useState(false);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const validate = (): boolean => {
    const newErrors: FormErrors = {};
    if (!form.nombre.trim()) {
      newErrors.nombre = "El nombre del idioma es obligatorio.";
    }
    if (!form.nivel.trim()) {
      newErrors.nivel = "El nivel es obligatorio.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const guardado = await onSave({
        nombre_idioma: form.nombre.trim(),
        nivel: form.nivel.trim(),
        visibilidad: form.visibilidad,
      });
      if (guardado === false) return;
      onClose();
    } catch (error: any) {
      console.error(error?.response?.data || error);
      setErrors({ nombre: "Error al guardar. Revisa los datos." });
    } finally {
      setLoading(false);
    }
  };

  const errStyle = { borderColor: "var(--red, #e53e3e)" };
  const errMsg = (msg?: string) =>
    msg ? <span style={{ fontSize: 11, color: "var(--red,#e53e3e)" }}>{msg}</span> : null;

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div className={styles.modalHead}>
          <span className={styles.modalTitle}>Registrar Idioma</span>
          <button className={styles.modalClose} onClick={onClose}>×</button>
        </div>

          <>
            <div className={styles.modalGrid}>
              {duplicadoWarning && (
                <div className={`${styles.duplicadoWarning} ${styles.modalFieldFull}`}>
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                    <line x1="12" y1="9" x2="12" y2="13"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                  </svg>
                  {duplicadoWarning}
                </div>
              )}

              <div className={`${styles.modalField} ${styles.modalFieldFull}`}>
                <label>Idioma *</label>
                <AutocompleteInput
                  name="nombre"
                  value={form.nombre}
                  onChange={(v) => {
                    setForm((prev) => ({ ...prev, nombre: v }));
                    if (errors.nombre) setErrors((prev) => ({ ...prev, nombre: undefined }));
                  }}
                  placeholder="Ej: Inglés, Francés, Portugués"
                  fetchSuggestions={getSugerenciasIdioma}
                  staticOptions={IDIOMAS_COMUNES}
                  hasError={!!errors.nombre}
                  minChars={1}
                />
                {errMsg(errors.nombre)}
              </div>

              <div className={`${styles.modalField} ${styles.modalFieldFull}`}>
                <label>Nivel *</label>
                <select
                  name="nivel"
                  value={form.nivel}
                  onChange={handleChange}
                  style={errors.nivel ? errStyle : {}}
                >
                    <option value="">Selecciona un nivel</option>
                    <option value="a1">A1 - Principiante</option>
                    <option value="a2">A2 - Básico</option>
                    <option value="b1">B1 - Intermedio</option>
                    <option value="b2">B2 - Intermedio alto</option>
                    <option value="c1">C1 - Avanzado</option>
                    <option value="c2">C2 - Maestría</option>
                    <option value="nativo">Nativo</option>
                </select>
                {errMsg(errors.nivel)}
              </div>
            </div>
            
            <div className={`${styles.modalField} ${styles.modalFieldFull}`}>
            <label>Visibilidad</label>
            <select
                name="visibilidad"
                value={form.visibilidad}
                onChange={handleChange}
            >
                <option value="publico">Público</option>
                <option value="privado">Privado</option>
            </select>
            </div>

            <div className={styles.modalActions}>
              <button className={styles.btnCancel} onClick={onClose}>
                Cancelar
              </button>
              <button className={styles.btnSave} onClick={handleSubmit} disabled={loading}>
                {loading ? (
                  <span className={styles.loadingContent}>
                    <span className={styles.spinner} aria-hidden="true" />
                    Guardando...
                  </span>
                ) : "Guardar"}
              </button>
            </div>
          </>
      </div>
    </div>
  );
}
