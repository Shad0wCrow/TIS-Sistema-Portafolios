import { useState, useRef } from "react"
import styles from "./createAccount-styles.module.css"
import Input from "../../components/ui/Input/input"
import ErrorMessage from "../../components/ui/ErrorMessage/ErrorMessage"
import Button from "../../components/ui/Button/button"
import { createProfile } from "../../services/profile"
import { useNavigate } from "react-router-dom"
import AutocompleteInput from "../../components/ui/AutocompleteInput/AutocompleteInput"

const PROFESIONES_SOFTWARE = [
    "Ingeniero de Software",
    "Desarrollador Full Stack",
    "Desarrollador Frontend",
    "Desarrollador Backend",
    "Ingeniero en Informática",
    "Ingeniero en Sistemas",
    "Analista de Sistemas",
    "Arquitecto de Software",
    "Ingeniero DevOps",
    "Especialista en Ciberseguridad",
]

const MAX_FOTO_BYTES = 5 * 1024 * 1024
const FORMATOS_FOTO = ["image/jpeg", "image/jpg", "image/png", "image/webp"]

interface FormValues {
    nombre: string
    apellido: string
    profesion: string
    celular: string
    descripcion: string
}

interface FormErrors {
    nombre?: string
    apellido?: string
    profesion?: string
    celular?: string
    descripcion?: string
    foto?: string
}

function validate(values: FormValues): FormErrors {
    const errors: FormErrors = {}

    if (!values.nombre.trim())
        errors.nombre = "El nombre es requerido"
    else if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(values.nombre))
        errors.nombre = "Solo se permiten letras"

    if (!values.apellido.trim())
        errors.apellido = "El apellido es requerido"
    else if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(values.apellido))
        errors.apellido = "Solo se permiten letras"

    if (!values.profesion.trim())
        errors.profesion = "La profesión es requerida"

    if (!values.celular.trim())
        errors.celular = "El celular es requerido"
    else if (!/^\d{7,15}$/.test(values.celular))
        errors.celular = "Ingresa un número válido (7-15 dígitos)"

    if (values.descripcion.length > 300)
        errors.descripcion = "Máximo 300 caracteres"
    else if (!values.descripcion.trim())
        errors.descripcion = "La descripción es requerida"

    return errors
}

async function fetchProfesiones(q: string): Promise<string[]> {
    return PROFESIONES_SOFTWARE.filter((p) =>
        p.toLowerCase().includes(q.toLowerCase())
    )
}

export default function CreateAccount() {
    const navigate = useNavigate()
    const fileInputRef = useRef<HTMLInputElement>(null)

    const [values, setValues] = useState<FormValues>({
        nombre: "",
        apellido: "",
        profesion: "",
        celular: "",
        descripcion: "",
    })

    const [errors, setErrors] = useState<FormErrors>({})
    const [touched, setTouched] = useState<Partial<Record<keyof FormValues, boolean>>>({})
    const [saving, setSaving] = useState(false)
    const [fotoPreview, setFotoPreview] = useState<string | null>(null)
    const [fotoError, setFotoError] = useState<string | undefined>(undefined)

    function handleChange(field: keyof FormValues) {
        return (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
            const updated = { ...values, [field]: e.target.value }
            setValues(updated)
            if (touched[field]) {
                setErrors(validate(updated))
            }
        }
    }

    function handleBlur(field: keyof FormValues) {
        return () => {
            setTouched((prev) => ({ ...prev, [field]: true }))
            setErrors(validate(values))
        }
    }

    function handleFotoChange(e: React.ChangeEvent<HTMLInputElement>) {
        const file = e.target.files?.[0]
        if (!file) return

        if (!FORMATOS_FOTO.includes(file.type)) {
            setFotoError("Formato no permitido. Usa JPG, PNG o WEBP.")
            setFotoPreview(null)
            e.target.value = ""
            return
        }

        if (file.size > MAX_FOTO_BYTES) {
            setFotoError("La imagen supera el límite de 5 MB.")
            setFotoPreview(null)
            e.target.value = ""
            return
        }

        setFotoError(undefined)
        const reader = new FileReader()
        reader.onload = () => setFotoPreview(reader.result as string)
        reader.readAsDataURL(file)
    }

    function handleQuitarFoto() {
        setFotoPreview(null)
        setFotoError(undefined)
        if (fileInputRef.current) fileInputRef.current.value = ""
    }

    const handleCancelar = () => {
        navigate("/dashboard")
    }

    async function handleGuardar() {
        if (saving) return

        const allTouched = Object.fromEntries(
            (Object.keys(values) as (keyof FormValues)[]).map((k) => [k, true])
        ) as Record<keyof FormValues, boolean>

        setTouched(allTouched)

        const currentErrors = validate(values)
        setErrors(currentErrors)

        if (Object.keys(currentErrors).length === 0) {
            setSaving(true)
            try {
                await createProfile({
                    nombre_perfil: values.nombre,
                    apellido_perfil: values.apellido,
                    profesion: values.profesion,
                    celular: values.celular,
                    descripcion: values.descripcion,
                })
                localStorage.setItem("hasProfile", "true")
                if (fotoPreview) {
                    localStorage.setItem("foto_perfil_cache", fotoPreview)
                }
                navigate("/dashboard")
            } catch (error) {
                console.error("Error al guardar perfil:", error)
            } finally {
                setSaving(false)
            }
        }
    }

    return (
        <main className={styles.page}>

            <aside className={styles.sidebar}>
                <div className={styles.sidebarTop}>
                    <div className={styles.brand}>
                        <span className={styles.brandTag}>Devfolio</span>
                    </div>
                    <p className={styles.brandName}>Crear perfil</p>
                    <p className={styles.brandSub}>Configuración de cuenta</p>
                </div>

                <div className={styles.avatarZone}>
                    <span className={styles.avatarZoneLabel}>Foto de perfil</span>
                    <div className={styles.avatarRow}>
                        <div
                            className={styles.avatar}
                            onClick={() => fileInputRef.current?.click()}
                        >
                            {fotoPreview ? (
                                <img
                                    src={fotoPreview}
                                    alt="Foto de perfil"
                                    className={styles.avatarPreview}
                                />
                            ) : (
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={styles.avatarIconSvg}>
                                    <circle cx="12" cy="8" r="4" />
                                    <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
                                </svg>
                            )}
                        </div>
                        <input
                            ref={fileInputRef}
                            type="file"
                            accept=".jpg,.jpeg,.png,.webp"
                            onChange={handleFotoChange}
                            style={{ display: "none" }}
                        />
                        <div className={styles.avatarInfo}>
                            {fotoPreview ? (
                                <button
                                    type="button"
                                    className={styles.quitarFoto}
                                    onClick={handleQuitarFoto}
                                >
                                    × Quitar foto
                                </button>
                            ) : (
                                <span
                                    className={styles.avatarHint}
                                    onClick={() => fileInputRef.current?.click()}
                                    style={{ cursor: "pointer" }}
                                >
                                    Agregar foto
                                </span>
                            )}
                            <span className={styles.avatarLabel}>JPG o PNG · máx 5 MB</span>
                            {fotoError && (
                                <span className={styles.avatarError}>{fotoError}</span>
                            )}
                        </div>
                    </div>
                </div>

                <div className={styles.steps}>
                    <span className={styles.stepsLabel}>Pasos</span>

                    <div className={styles.step}>
                        <div className={`${styles.stepNum} ${styles.stepNumDone}`}>✓</div>
                        <div className={styles.stepText}>
                            <div className={styles.stepName}>Cuenta creada</div>
                            <div className={styles.stepDesc}>Email y contraseña</div>
                        </div>
                    </div>

                    <div className={styles.step}>
                        <div className={`${styles.stepNum} ${styles.stepNumActive}`}>2</div>
                        <div className={styles.stepText}>
                            <div className={styles.stepName}>Datos del perfil</div>
                            <div className={styles.stepDesc}>Nombre, profesión, contacto</div>
                        </div>
                    </div>

                    <div className={styles.step}>
                        <div className={styles.stepNum}>3</div>
                        <div className={styles.stepText}>
                            <div className={`${styles.stepName} ${styles.stepNamePending}`}>Portafolio</div>
                            <div className={styles.stepDesc}>Proyectos y trabajos</div>
                        </div>
                    </div>

                    <div className={styles.step}>
                        <div className={styles.stepNum}>4</div>
                        <div className={styles.stepText}>
                            <div className={`${styles.stepName} ${styles.stepNamePending}`}>Publicar</div>
                            <div className={styles.stepDesc}>Revisa y lanza tu perfil</div>
                        </div>
                    </div>
                </div>

                <div className={styles.sidebarFooter}>
                    <div className={styles.progressLabel}>
                        <span className={styles.progressLabelText}>Progreso</span>
                        <span className={styles.progressLabelStep}>Paso 2 de 4</span>
                    </div>
                    <div className={styles.progressBar}>
                        <div className={styles.progressFill} />
                    </div>
                </div>
            </aside>

            <div className={styles.main}>

                <div className={styles.topbar}>
                    <div className={styles.topbarLeft}>
                        <span className={styles.topbarStep}>Paso 2</span>
                        <div className={styles.topbarSep} />
                        <span className={styles.topbarPath}>
                            Configuración →{" "}
                            <span className={styles.topbarPathStrong}>Perfil</span>
                        </span>
                    </div>
                    <div className={styles.topbarRight}>
                        <span className={styles.topbarBadge}>
                            <span className={styles.topbarDot} />
                            Guardado automático
                        </span>
                    </div>
                </div>

                <div className={styles.formBody}>

                    <div className={styles.section}>
                        <div className={styles.sectionTag}>
                            <div className={styles.sectionTagLeft}>
                                <div className={styles.tagNum}>1</div>
                                <span className={styles.tagLabel}>Datos personales</span>
                            </div>
                        </div>
                        <div className={styles.sectionCard}>
                            <div className={styles.grid}>
                                <div className={styles.fieldGroup}>
                                    <label className={styles.label}>Nombre</label>
                                    <Input
                                        type="text"
                                        placeholder=""
                                        classname={styles.input}
                                        value={values.nombre}
                                        onChange={handleChange("nombre")}
                                        onBlur={handleBlur("nombre")}
                                        error={!!errors.nombre && touched.nombre}
                                    />
                                    <ErrorMessage message={touched.nombre ? errors.nombre : undefined} />
                                </div>
                                <div className={styles.fieldGroup}>
                                    <label className={styles.label}>Apellido</label>
                                    <Input
                                        type="text"
                                        placeholder=""
                                        classname={styles.input}
                                        value={values.apellido}
                                        onChange={handleChange("apellido")}
                                        onBlur={handleBlur("apellido")}
                                        error={!!errors.apellido && touched.apellido}
                                    />
                                    <ErrorMessage message={touched.apellido ? errors.apellido : undefined} />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className={styles.section}>
                        <div className={styles.sectionTag}>
                            <div className={styles.sectionTagLeft}>
                                <div className={styles.tagNum}>2</div>
                                <span className={styles.tagLabel}>Información profesional</span>
                            </div>
                        </div>
                        <div className={styles.sectionCard}>
                            <div className={styles.grid}>
                                <div className={styles.fieldGroup}>
                                    <label className={styles.label}>Profesión</label>
                                    <AutocompleteInput
                                        name="profesion"
                                        value={values.profesion}
                                        onChange={(v) => {
                                            const updated = { ...values, profesion: v }
                                            setValues(updated)
                                            if (touched.profesion) setErrors(validate(updated))
                                        }}
                                        onBlur={handleBlur("profesion")}
                                        placeholder="Ej: Ingeniero de Software"
                                        fetchSuggestions={fetchProfesiones}
                                        staticOptions={PROFESIONES_SOFTWARE}
                                        hasError={!!errors.profesion && touched.profesion}
                                        minChars={1}
                                    />
                                    <ErrorMessage message={touched.profesion ? errors.profesion : undefined} />
                                </div>
                                <div className={styles.fieldGroup}>
                                    <label className={styles.label}>Celular</label>
                                    <Input
                                        type="tel"
                                        placeholder=""
                                        classname={styles.input}
                                        value={values.celular}
                                        onChange={handleChange("celular")}
                                        onBlur={handleBlur("celular")}
                                        error={!!errors.celular && touched.celular}
                                    />
                                    <ErrorMessage message={touched.celular ? errors.celular : undefined} />
                                </div>
                                <div className={`${styles.fieldGroup} ${styles.textareaWrapper}`}>
                                    <label className={styles.label}>Descripción</label>
                                    <textarea
                                        className={styles.textarea}
                                        value={values.descripcion}
                                        onChange={handleChange("descripcion")}
                                        onBlur={handleBlur("descripcion")}
                                        placeholder="Cuéntanos sobre ti y tu trabajo..."
                                    />
                                    <div className={styles.charHint}>
                                        {values.descripcion.length} / 300
                                    </div>
                                    <ErrorMessage message={touched.descripcion ? errors.descripcion : undefined} />
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div className={styles.greenAccent} />

                <div className={styles.actions}>
                    <span className={styles.actionsHint}>Puedes omitir este paso y crear tu perfil después</span>
                    <div className={styles.actionsRight}>
                        <Button text="Omitir" className={styles.cancel} onClick={handleCancelar} />
                        <Button
                            text="Guardar perfil →"
                            loadingText="Guardando..."
                            className={styles.save}
                            onClick={handleGuardar}
                            loading={saving}
                        />
                    </div>
                </div>

            </div>

        </main>
    )
}