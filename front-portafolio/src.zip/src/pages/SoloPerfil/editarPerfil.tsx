import { useState, useEffect, useRef, type ChangeEvent } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./editarPerfil.module.css";
import { getPortafolio, updatePerfil, getSugerenciasProfecion } from "../../services/portafolioservice";
import type { PortafolioData } from "../../types/portafolioTypes";
import AutocompleteInput from "../../components/ui/AutocompleteInput/AutocompleteInput";
import { IconPersona, IconPencil } from "../editPortafolio/components/icons";

const SOLO_LETRAS = /^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s'-]+$/;
const SOLO_NUMEROS = /^\+?[0-9\s\-()]{7,20}$/;
const CARACTERES_PELIGROSOS = /[<>"'`;{}()]/;
const MAX_FOTO_BYTES = 5 * 1024 * 1024;
const FORMATOS_FOTO = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

interface FormState {
    nombre_perfil: string;
    apellido_perfil: string;
    profesion: string;
    celular: string;
    descripcion: string;
}

interface FormErrors {
    nombre_perfil?: string;
    apellido_perfil?: string;
    profesion?: string;
    celular?: string;
    descripcion?: string;
    foto?: string;
}

function validar(form: FormState): FormErrors {
    const errs: FormErrors = {};

    if (!form.nombre_perfil.trim()) errs.nombre_perfil = "El nombre es obligatorio.";
    else if (!SOLO_LETRAS.test(form.nombre_perfil.trim())) errs.nombre_perfil = "Solo se permiten letras.";
    else if (form.nombre_perfil.trim().length > 50) errs.nombre_perfil = "Máximo 50 caracteres.";

    if (!form.apellido_perfil.trim()) errs.apellido_perfil = "El apellido es obligatorio.";
    else if (!SOLO_LETRAS.test(form.apellido_perfil.trim())) errs.apellido_perfil = "Solo se permiten letras.";
    else if (form.apellido_perfil.trim().length > 50) errs.apellido_perfil = "Máximo 50 caracteres.";

    if (!form.profesion.trim()) errs.profesion = "La profesión es obligatoria.";
    else if (CARACTERES_PELIGROSOS.test(form.profesion)) errs.profesion = "Caracteres no permitidos.";
    else if (form.profesion.trim().length > 100) errs.profesion = "Máximo 100 caracteres.";

    if (!form.celular.trim()) errs.celular = "El teléfono es obligatorio.";
    else if (!SOLO_NUMEROS.test(form.celular.trim())) errs.celular = "Solo números, espacios, +, - o paréntesis (7-20 dígitos).";

    if (!form.descripcion.trim()) errs.descripcion = "La descripción es obligatoria.";
    else if (CARACTERES_PELIGROSOS.test(form.descripcion)) errs.descripcion = "Caracteres no permitidos.";
    else if (form.descripcion.length > 300) errs.descripcion = "Máximo 300 caracteres.";

    return errs;
}

export default function EditarPerfil() {
    const navigate = useNavigate();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const [data, setData] = useState<PortafolioData | null>(null);
    const [loadingPage, setLoadingPage] = useState(true);
    const [errorPage, setErrorPage] = useState("");

    const [form, setForm] = useState<FormState>({
        nombre_perfil: "",
        apellido_perfil: "",
        profesion: "",
        celular: "",
        descripcion: "",
    });

    const [errors, setErrors] = useState<FormErrors>({});
    const [touched, setTouched] = useState<Partial<Record<keyof FormState, boolean>>>({});
    const [saving, setSaving] = useState(false);
    const [successMsg, setSuccessMsg] = useState<string | null>(null);

    const [fotoPreview, setFotoPreview] = useState<string | null>(null);
    const [fotoError, setFotoError] = useState<string | undefined>(undefined);
    const [editandoFoto, setEditandoFoto] = useState(false);

    useEffect(() => {
        getPortafolio()
            .then((res) => {
                setData(res);
                const p = res.perfil;
                if (p) {
                    setForm({
                        nombre_perfil: p.nombre_perfil ?? "",
                        apellido_perfil: p.apellido_perfil ?? "",
                        profesion: p.profesion ?? "",
                        celular: p.celular ?? "",
                        descripcion: p.descripcion ?? "",
                    });
                    if (p.foto_url) setFotoPreview(p.foto_url);
                    else {
                        const cached = localStorage.getItem("foto_perfil_cache");
                        if (cached) setFotoPreview(cached);
                    }
                }
            })
            .catch(() => setErrorPage("No se pudo cargar el perfil."))
            .finally(() => setLoadingPage(false));
    }, []);

    function handleChange(field: keyof FormState) {
        return (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
            const updated = { ...form, [field]: e.target.value };
            setForm(updated);
            if (touched[field]) setErrors(validar(updated));
        };
    }

    function handleBlur(field: keyof FormState) {
        return () => {
            setTouched((prev) => ({ ...prev, [field]: true }));
            setErrors(validar(form));
        };
    }

    function handleFotoChange(e: ChangeEvent<HTMLInputElement>) {
        const file = e.target.files?.[0];
        if (!file) return;

        if (!FORMATOS_FOTO.includes(file.type)) {
            setFotoError("Formato no permitido. Usa JPG, PNG o WEBP.");
            e.target.value = "";
            return;
        }
        if (file.size > MAX_FOTO_BYTES) {
            setFotoError("La imagen supera el límite de 5 MB.");
            e.target.value = "";
            return;
        }

        setFotoError(undefined);
        const reader = new FileReader();
        reader.onload = () => {
            const result = reader.result as string;
            setFotoPreview(result);
            localStorage.setItem("foto_perfil_cache", result);
        };
        reader.readAsDataURL(file);
        setEditandoFoto(false);
    }

    function handleQuitarFoto() {
        setFotoPreview(null);
        setFotoError(undefined);
        localStorage.removeItem("foto_perfil_cache");
        if (fileInputRef.current) fileInputRef.current.value = "";
    }

    async function handleGuardar() {
        if (saving) return;

        const allTouched = Object.fromEntries(
            (Object.keys(form) as (keyof FormState)[]).map((k) => [k, true])
        ) as Record<keyof FormState, boolean>;
        setTouched(allTouched);

        const currentErrors = validar(form);
        setErrors(currentErrors);

        if (Object.keys(currentErrors).length > 0) return;

        setSaving(true);
        try {
            await updatePerfil({
                nombre_perfil: form.nombre_perfil.trim(),
                apellido_perfil: form.apellido_perfil.trim(),
                profesion: form.profesion.trim(),
                celular: form.celular.trim(),
                descripcion: form.descripcion.trim(),
                foto_url: fotoPreview?.startsWith("http") ? fotoPreview : undefined,
            });
            setSuccessMsg("Perfil actualizado correctamente.");
            setTimeout(() => setSuccessMsg(null), 3000);
        } catch {
            setErrors({ descripcion: "Error al guardar. Intenta de nuevo." });
        } finally {
            setSaving(false);
        }
    }

    if (loadingPage)
        return <div className={styles.stateScreen}>Cargando perfil...</div>;
    if (errorPage)
        return <div className={`${styles.stateScreen} ${styles.stateError}`}>{errorPage}</div>;

    return (
        <div className={styles.layout}>
            {/* El div main ahora ocupará todo el ancho si ajustas el CSS de layout */}
            <div className={styles.main}>
                <div className={styles.topbar}>
                    <div className={styles.topbarLeft}>
                        <span className={styles.breadcrumb}>
                            Dashboard
                            <span className={styles.breadcrumbSep}>›</span>
                            <span className={styles.breadcrumbCurrent}>Perfil</span>
                        </span>
                    </div>
                    <div className={styles.topbarRight}>
                        {successMsg && (
                            <span className={styles.statusBadge}>
                                <span className={styles.statusDot} />
                                {successMsg}
                            </span>
                        )}
                    </div>
                </div>

                <div className={styles.content}>
                    {/* Sección Foto */}
                    <div className={styles.section}>
                        <div className={styles.sectionHeader}>
                            <span className={styles.sectionTitle}>Foto de perfil</span>
                        </div>
                        <div className={styles.fotoCard}>
                            <div className={styles.fotoLeft}>
                                <div
                                    className={styles.fotoCircle}
                                    onClick={() => setEditandoFoto(true)}
                                >
                                    {fotoPreview ? (
                                        <img src={fotoPreview} alt="Foto de perfil" />
                                    ) : (
                                        <IconPersona />
                                    )}
                                    <div className={styles.fotoOverlay}>
                                        <IconPencil />
                                    </div>
                                </div>
                            </div>
                            <div className={styles.fotoRight}>
                                {editandoFoto ? (
                                    <div className={styles.fotoUploadArea}>
                                        <input
                                            ref={fileInputRef}
                                            type="file"
                                            accept=".jpg,.jpeg,.png,.webp"
                                            onChange={handleFotoChange}
                                            style={{ display: "none" }}
                                        />
                                        <button
                                            className={styles.fotoUploadBtn}
                                            onClick={() => fileInputRef.current?.click()}
                                        >
                                            Seleccionar imagen
                                        </button>
                                        <button
                                            className={styles.fotoCancelBtn}
                                            onClick={() => setEditandoFoto(false)}
                                        >
                                            Cancelar
                                        </button>
                                        <p className={styles.fotoHint}>JPG, PNG o WEBP · Máx. 5 MB</p>
                                        {fotoError && (
                                            <span className={styles.fotoError}>{fotoError}</span>
                                        )}
                                    </div>
                                ) : (
                                    <div className={styles.fotoActions}>
                                        <button
                                            className={styles.editBtn}
                                            onClick={() => setEditandoFoto(true)}
                                        >
                                            <IconPencil />
                                            Cambiar foto
                                        </button>
                                        {fotoPreview && (
                                            <button
                                                className={styles.removeBtn}
                                                onClick={handleQuitarFoto}
                                            >
                                                Quitar foto
                                            </button>
                                        )}
                                        <p className={styles.fotoHint}>
                                            {fotoPreview
                                                ? "Haz clic en la imagen o en «Cambiar foto» para actualizarla."
                                                : "Aún no tienes foto de perfil. Haz clic en «Cambiar foto» para subir una."}
                                        </p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Sección Datos Personales */}
                    <div className={styles.section}>
                        <div className={styles.sectionHeader}>
                            <span className={styles.sectionTitle}>Datos personales</span>
                        </div>
                        <div className={styles.formCard}>
                            <div className={styles.grid}>
                                <div className={styles.fieldGroup}>
                                    <label className={styles.label}>Nombre</label>
                                    <input
                                        className={`${styles.input} ${errors.nombre_perfil && touched.nombre_perfil ? styles.inputError : ""}`}
                                        value={form.nombre_perfil}
                                        onChange={handleChange("nombre_perfil")}
                                        onBlur={handleBlur("nombre_perfil")}
                                        placeholder="Tu nombre"
                                        maxLength={50}
                                    />
                                    {touched.nombre_perfil && errors.nombre_perfil && (
                                        <span className={styles.fieldError}>{errors.nombre_perfil}</span>
                                    )}
                                </div>
                                <div className={styles.fieldGroup}>
                                    <label className={styles.label}>Apellido</label>
                                    <input
                                        className={`${styles.input} ${errors.apellido_perfil && touched.apellido_perfil ? styles.inputError : ""}`}
                                        value={form.apellido_perfil}
                                        onChange={handleChange("apellido_perfil")}
                                        onBlur={handleBlur("apellido_perfil")}
                                        placeholder="Tu apellido"
                                        maxLength={50}
                                    />
                                    {touched.apellido_perfil && errors.apellido_perfil && (
                                        <span className={styles.fieldError}>{errors.apellido_perfil}</span>
                                    )}
                                </div>
                                <div className={styles.fieldGroup}>
                                    <label className={styles.label}>Profesión</label>
                                    <AutocompleteInput
                                        name="profesion"
                                        value={form.profesion}
                                        onChange={(v) => {
                                            const updated = { ...form, profesion: v };
                                            setForm(updated);
                                            if (touched.profesion) setErrors(validar(updated));
                                        }}
                                        onBlur={handleBlur("profesion")}
                                        placeholder="Ej: Ingeniero de Software"
                                        fetchSuggestions={getSugerenciasProfecion}
                                        hasError={!!errors.profesion && !!touched.profesion}
                                        minChars={2}
                                    />
                                    {touched.profesion && errors.profesion && (
                                        <span className={styles.fieldError}>{errors.profesion}</span>
                                    )}
                                </div>
                                <div className={styles.fieldGroup}>
                                    <label className={styles.label}>Teléfono</label>
                                    <input
                                        className={`${styles.input} ${errors.celular && touched.celular ? styles.inputError : ""}`}
                                        value={form.celular}
                                        onChange={handleChange("celular")}
                                        onBlur={handleBlur("celular")}
                                        placeholder="+591 7XXXXXXX"
                                        maxLength={20}
                                    />
                                    {touched.celular && errors.celular && (
                                        <span className={styles.fieldError}>{errors.celular}</span>
                                    )}
                                </div>
                                <div className={`${styles.fieldGroup} ${styles.fieldFull}`}>
                                    <label className={styles.label}>Descripción</label>
                                    <textarea
                                        className={`${styles.textarea} ${errors.descripcion && touched.descripcion ? styles.inputError : ""}`}
                                        value={form.descripcion}
                                        onChange={handleChange("descripcion")}
                                        onBlur={handleBlur("descripcion")}
                                        placeholder="Cuéntanos sobre ti y tu trabajo..."
                                        maxLength={300}
                                        rows={4}
                                    />
                                    <div className={styles.charHint}>{form.descripcion.length} / 300</div>
                                    {touched.descripcion && errors.descripcion && (
                                        <span className={styles.fieldError}>{errors.descripcion}</span>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className={styles.footer}>
                    <span className={styles.footerHint}>
                        Los cambios se guardan al presionar el botón
                    </span>
                    <div className={styles.footerActions}>
                        <button
                            className={styles.cancelBtn}
                            onClick={() => navigate("/dashboard")}
                            disabled={saving}
                        >
                            Cancelar
                        </button>
                        <button
                            className={styles.saveBtn}
                            onClick={handleGuardar}
                            disabled={saving}
                        >
                            {saving ? (
                                <span className={styles.savingContent}>
                                    <span className={styles.spinner} />
                                    Guardando...
                                </span>
                            ) : (
                                "Guardar cambios"
                            )}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}